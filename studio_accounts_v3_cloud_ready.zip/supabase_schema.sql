-- STUDIO ACCOUNTS V3 DATABASE
-- Run this in Supabase SQL Editor.

create extension if not exists pgcrypto;

create table if not exists public.clients (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  phone text,
  project text not null,
  total numeric(12,2) not null default 0,
  created_at timestamptz not null default now()
);

create table if not exists public.payments (
  id uuid primary key default gen_random_uuid(),
  client_id uuid references public.clients(id) on delete cascade,
  amount numeric(12,2) not null check (amount > 0),
  received_by text not null check (received_by in ('Harsh','Harmeet')),
  method text not null default 'UPI',
  created_at timestamptz not null default now()
);

create table if not exists public.expenses (
  id uuid primary key default gen_random_uuid(),
  description text not null,
  amount numeric(12,2) not null check (amount > 0),
  paid_by text not null check (paid_by in ('Harsh','Harmeet')),
  category text not null default 'Other',
  created_at timestamptz not null default now()
);

create table if not exists public.invoices (
  id uuid primary key default gen_random_uuid(),
  invoice_number text unique not null,
  client_id uuid references public.clients(id) on delete cascade,
  amount numeric(12,2) not null check (amount >= 0),
  notes text,
  created_at timestamptz not null default now()
);

alter table public.clients enable row level security;
alter table public.payments enable row level security;
alter table public.expenses enable row level security;
alter table public.invoices enable row level security;

-- MVP policy: any authenticated partner account can read/write studio data.
-- Tighten this later with a partners table and role policies.
create policy "authenticated clients access" on public.clients for all to authenticated using (true) with check (true);
create policy "authenticated payments access" on public.payments for all to authenticated using (true) with check (true);
create policy "authenticated expenses access" on public.expenses for all to authenticated using (true) with check (true);
create policy "authenticated invoices access" on public.invoices for all to authenticated using (true) with check (true);
